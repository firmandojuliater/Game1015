<?php
require "dbConnect.php";
$result = array();
$query = "INSERT INTO tb_periode(date) VALUES(NOW())";
if(mysqli_query($conn, $query)){
    $temp = [
        'message'=>"Data berhasil disimpan"
    ];
    array_push($result, $temp);
}else{
    $temp = [
        'message'=>"Data gagal disimpan"
    ];
    array_push($result, $temp);
}
echo json_encode($result);
?>