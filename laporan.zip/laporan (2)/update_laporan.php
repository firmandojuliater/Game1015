<?php
require "dbConnect.php";
$id_laporan=$_POST['id_laporan'];
$penjualan_sementara=$_POST['penjualan_sementara'];
$penjualan_total=$_POST['penjualan_total'];
$pembelian_sementara=$_POST['pembelian_sementara'];
$pembelian_total=$_POST['pembelian_total'];
$total=$_POST['total'];
$keterangan=$_POST['keterangan'];
$username=$_POST['username'];
$result = array();
if($id_laporan!="" AND $penjualan_sementara!="" AND $penjualan_total!="" AND $pembelian_sementara!="" AND $pembelian_total!="" AND $total!="" AND $keterangan!=""){
    $query = "UPDATE tb_laporan SET penjualan_sementara='$penjualan_sementara', penjualan_total='$penjualan_total', pembelian_sementara='$pembelian_sementara', pembelian_total='$pembelian_total', total='$total', keterangan='$keterangan' WHERE id_laporan='$id_laporan' AND created_by='$username' AND periode IN (SELECT max(id_periode) from tb_periode)";
    if(mysqli_query($conn, $query)){
        $temp = [
            'message'=>"Data berhasil disimpan"
        ];
        array_push($result, $temp);
    }else{
        $temp = [
            'message'=>"Data gagal disimpan"
        ];
        array_push($result, $temp);
    }
}else{
    $temp = [
        'message'=>"Data tidak boleh kosong"
    ];
    array_push($result, $temp);
}
echo json_encode($result);
?>